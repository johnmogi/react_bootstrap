import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Header from "../header/header";
import NavComp from "../header/navbar";
import Footer from "../footer/footer";
import Side from "../side/side";
import Jumbotron from "react-bootstrap/Jumbotron";
import { BrowserRouter, Switch, Route } from "react-router-dom";
// import Selector from "../selector/selector";

class Layout extends React.Component {
  render() {
    return (
      <Container className="container-fluid layout">
        <NavComp />

        <Row>
          <Col sm={3}>
            <Side />
          </Col>
          <Col sm={9}>
            <Jumbotron>
              <BrowserRouter>
                <Switch>
                  <Route path="/" component={Header} exact />
                  {/* <Route path="/home" component={Selector} exact /> */}
                </Switch>
              </BrowserRouter>
            </Jumbotron>
          </Col>
        </Row>
        <Footer />
      </Container>
    );
  }
}

export default Layout;
