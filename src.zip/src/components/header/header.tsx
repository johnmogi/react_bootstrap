import React from "react";
import Jumbotron from "react-bootstrap/Jumbotron";

class Header extends React.Component {
  render() {
    return (
      <section className="header">
        <h1>Welcome To React-Bootstrap TypeScript Example</h1>
      </section>
    );
  }
}

export default Header;
