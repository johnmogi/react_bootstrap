import React from "react";
import Nav from "react-bootstrap/Nav";
export interface Props {
  arr: {
    home: "/home";
  };
}

class Side extends React.Component {
  render() {
    return (
      <aside className="text-center">
        <Nav defaultActiveKey="/home" className="flex-column">
          <Nav.Link href="{this.setState.home}">Active</Nav.Link>
          <Nav.Link eventKey="link-1">Link</Nav.Link>
          <Nav.Link eventKey="link-2">Link</Nav.Link>
          <Nav.Link eventKey="disabled" disabled>
            Disabled
          </Nav.Link>
        </Nav>
      </aside>
    );
  }
}

export default Side;
