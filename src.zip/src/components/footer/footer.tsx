import React from "react";

class Footer extends React.Component {
  render() {
    return (
      <footer className="text-center">
        all rights reserved &copy; John Mogi
      </footer>
    );
  }
}

export default Footer;
